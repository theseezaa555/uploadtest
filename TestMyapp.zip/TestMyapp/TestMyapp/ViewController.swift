//
//  ViewController.swift
//  TestMyapp
//
//  Created by Suparlerk on 4/8/2559 BE.
//  Copyright © 2559 Suparlerk. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lab: UILabel!

    @IBOutlet weak var textf: UITextField!

    @IBOutlet weak var pass: UITextField!
    
    var username = "";
    var password = "";
    var value = 0;
    
    @IBAction func sub(sender: UIButton) {
        username = textf.text!;
        password = pass.text!;
        if(username == "gypsy" && password == "123456"){
            let alert = UIAlertController(title: "Alert", message: "Log in Complete", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Click", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        } else{
            let alert = UIAlertController(title: "Alert", message: "Invalid Username or Password", preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Click", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alert, animated: true, completion: nil)
        }
        
        
    }
   
    @IBAction func cancel(sender: AnyObject) {
        textf.text = "";
        pass.text = "";
    }
    var label: UILabel?
    override func viewDidLoad() {
        super.viewDidLoad()
        let button   = UIButton(type: UIButtonType.System) as UIButton
        button.frame = CGRectMake(100, 300, 100, 50)
        //button.backgroundColor = UIColor.greenColor() // set backgroud button
        button.setTitle("Test Button", forState: UIControlState.Normal)
        button.addTarget(self, action: "buttonAction:", forControlEvents: UIControlEvents.TouchUpInside)
        
        self.view.addSubview(button)
        
    }
    
    func buttonAction(sender:UIButton!)
    {
        
        lab.text = "Hello World"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

